const db = require("./db");

const FIELDS = [
  "fld_lname",
  "fld_mname",
  "fld_fname",
  "fld_extname",
  "fld_username",
  "fld_email"
];

const User = {
  async all() {
    const [rows] = await db.execute("SELECT * FROM tbl_users");
    return rows;
  },

  async find(username) {
    const [rows] = await db.execute("SELECT * FROM tbl_users WHERE fld_username=?", [username]);
    console.log('searching for:', username, 'found:', rows);
    return rows;
  }
}

module.exports = User;