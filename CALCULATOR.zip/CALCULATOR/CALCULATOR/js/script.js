/* ==============================================================================
# ATTRIBUTION: Calculator Source Code
# Submitted by: course-org/classroom-demos-2026
# Block: BSIT-3D
# Class and Subject Code: 45460 - ITP313L
# ============================================================================== */


/* ====== Your code starts below ====== */

const previousOperandEl = document.getElementById('previous-operand');
const currentOperandEl = document.getElementById('current-operand');

let currentOperand = '0';
let previousOperand = '';
let operator = null;


function updateDisplay() {
  currentOperandEl.textContent = currentOperand;
  previousOperandEl.textContent = previousOperand + (operator ? ' ' + operator : '');
}


function appendNumber(number) {
  if (number === '.' && currentOperand.includes('.')) return; 
  if (currentOperand === '0' && number !== '.') {
    currentOperand = number;
  } else {
    currentOperand += number;
  }
}


function chooseOperator(value) {
  if (currentOperand === '') return;
  if (previousOperand !== '') {
    calculate();
  }
  operator = value;
  previousOperand = currentOperand;
  currentOperand = '';
}

function calculate() {
  let result;
  const prev = parseFloat(previousOperand);
  const current = parseFloat(currentOperand);

  if (isNaN(prev) || isNaN(current)) return;

  if (operator === '+') {
    result = prev + current;
  } else if (operator === '-') {
    result = prev - current;
  } else if (operator === '*') {
    result = prev * current;
  } else if (operator === '/') {
    result = prev / current;
  } else {
    return;
  }

  currentOperand = result.toString();
  operator = null;
  previousOperand = '';
}


function clearAll() {
  currentOperand = '0';
  previousOperand = '';
  operator = null;
}


function deleteLast() {
  currentOperand = currentOperand.toString().slice(0, -1);
  if (currentOperand === '') currentOperand = '0';
}


function percent() {
  currentOperand = (parseFloat(currentOperand) / 100).toString();
}


document.querySelectorAll('.btn-number').forEach(button => {
  button.addEventListener('click', () => {
    appendNumber(button.dataset.number);
    updateDisplay();
  });
});


document.querySelectorAll('.btn-operator').forEach(button => {
  button.addEventListener('click', () => {
    if (button.dataset.action === 'percent') {
      percent();
    } else {
      chooseOperator(button.dataset.value);
    }
    updateDisplay();
  });
});


document.querySelector('.btn-equals').addEventListener('click', () => {
  calculate();
  updateDisplay();
});


document.querySelectorAll('.btn-clear').forEach(button => {
  button.addEventListener('click', () => {
    if (button.dataset.action === 'clear') {
      clearAll();
    } else if (button.dataset.action === 'delete') {
      deleteLast();
    }
    updateDisplay();
  });
});